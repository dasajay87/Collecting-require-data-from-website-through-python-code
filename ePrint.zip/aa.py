from bs4 import BeautifulSoup
import requests
#from html_content import html_content
from fpdf import FPDF

def extract_paper_titles_and_categories(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')

    parent_divs = soup.find_all('div', class_="ms-3 ms-md-5 mb-3")
    # print(parent_divs[0])
    
    file_data = []

    for div in parent_divs:
        papertitle = div.find_all('div', class_='papertitle')[0].text
        category = div.find_all('small')[0].text
    
        # print(papertitle, category)

        file_data.append(f"Paper Title: {papertitle}\nCategory: {category}\n\n")

    return file_data

#Downloading HTML file from ePrint server for last 7 days updated
def download_text_from_web(link):
    try:
        response = requests.get(link)
        if response.status_code == 200:
            return response.text
        else:
            print("Failed to download text. Status code:", response.status_code)
            return None
    except Exception as e:
        print("An error occurred:", e)
        return None

#Text to PDF conversion
def text_to_pdf(eprint):
    # save FPDF() class into 
    # a variable pdf
    pdf = FPDF()   
  
    # Add a page
    pdf.add_page()
  
    # set style and size of font 
    # that you want in the pdf
    pdf.set_font("Arial", size = 12)
 
    # open the text file in read mode
    f = open(eprint, "r")
    # print(f.readlines(), type(f))
    l = f.readlines()
 
    # insert the texts in pdf
    for x in l:
        print(x, type(x))
        pdf.cell(200, 10, txt = x, ln = 1, align = 'C')
  
    # save the pdf with name .pdf
    pdf.output("ePrint_Updated.pdf")


#main code 
    
url = "https://eprint.iacr.org/days/7"
html_content = download_text_from_web(url)  
#extract_paper_titles_and_categories(html_content)
paper_titles = extract_paper_titles_and_categories(html_content)
# Specify the file path
file_path = "ePrint_new.txt"
file = open(file_path, 'w')
i = 1
for title in paper_titles:
        
            # Write the content to the file
            #file.write(str(print('_' * 50 + "paper" + str(i) + '_' * 50)))
            file.write(str('_' * 50 + "paper" + str(i) + '_' * 50))
            #print('_' * 50 + "paper" + str(i) + '_' * 50)
            file.write("\n")
            #file.write(str(print(title)))
            file.write(str(title))
            file.write("\n")
            i += 1

file.write("\n")      
print("Total number of papers published in last week :", i-1)
file.write("Total number of papers published in last week :" + str(i-1))
# Example usage
file.close()
text_to_pdf("ePrint_new.txt")
